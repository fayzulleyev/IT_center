from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup

button6 = InlineKeyboardButton(text="7 yoshdan 12 yoshgacha",callback_data="7 yosh")
button7 = InlineKeyboardButton(text="13 yoshdan kattalar",callback_data="13 yosh")
keyboard1 = InlineKeyboardMarkup().add(button6).add(button7)

button6 = InlineKeyboardButton(text="Python",callback_data="py")
button7 = InlineKeyboardButton(text="Java",callback_data="java")
button8 = InlineKeyboardButton(text="JavaScript",callback_data="js")
keyboard2 = InlineKeyboardMarkup().row(button6,button7).add(button8)

button10 = InlineKeyboardButton(text='IT PARK Qorasuv👨‍💻',url="https://t.me/itqorasuv")
button17 = InlineKeyboardButton(text="Tasdiqlash✅",callback_data="tasdiqlash")
keyboard4 = InlineKeyboardMarkup().add(button10).add(button17)

button11 = InlineKeyboardButton(text="Savodxonlik✅",callback_data="savodxonlik")
button12 = InlineKeyboardButton(text="Scratch🕹",callback_data="scratch")
button13 = InlineKeyboardButton(text="Python📌",callback_data="python")
button14 = InlineKeyboardButton(text="Java👨‍💻",callback_data="ja")
button15 = InlineKeyboardButton(text="Grafika💻",callback_data="grafika")
button16 = InlineKeyboardButton(text="Fronted🔫",callback_data="fronted")
keyboard5 = InlineKeyboardMarkup().row(button11,button12).row(button13,button14).row(button15,button16)


