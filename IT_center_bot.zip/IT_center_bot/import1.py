from text import *
from button import *
from email import message
from subprocess import call
from aiogram import Bot,Dispatcher,executor,types
from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup