api_token = ""

from import1 import *

bot = Bot(token=api_token)
dp=Dispatcher(bot)

s = 0
@dp.message_handler(commands="start")
async def start(message:types.Message):
    await message.answer("Salom. Kanalimizga obuna bo'ling",reply_markup=keyboard4)
    print(message)
    global s
    s=s+1
    print(f"Foydalanuvchilar soni{s}")


@dp.message_handler(commands="about")
async def about(message:types.Message):
    await message.answer(f"Bizning o'quv markazimizda profisianal o'qituvchilar dars berishadi. 𝘐𝘛 𝘤𝘦𝘯𝘵𝘦𝘳 𝘰'𝘲𝘶𝘷 𝘬𝘶𝘳𝘴𝘭𝘢𝘳𝘪: {a} Batafsil o'quv markazimiz haqida https://it-park.uz/ quyida saytdan ma'lumot olishingiz mumkin.\n Telegram kanalimiz - https://t.me/itqorasuv \n Regestratsiyadan o'tish uchun - @Tewayev_Abbos")


@dp.message_handler(commands="course")
async def course(message:types.Message):
    await message.answer("Yoshni tanlang ❗️",reply_markup=keyboard1)


@dp.message_handler(commands="help")
async def help(message:types.Message):
    await message.answer(helpp)


@dp.message_handler(commands="days")
async def help(message:types.Message):
    await message.answer("O'quv kursini tanlang",reply_markup=keyboard5)
    

@dp.callback_query_handler(text=["savodxonlik","ortga","tasdiqlash","scratch","ja","grafika","fronted","python","kompyuter","dasturlash","dizayn","robototexnika","sport","py","java","js","7 yosh", "13 yosh","scrench","kanal"])
async def center(call:types.CallbackQuery):
    global keyboard1
    if call.data == "ortga":
        await call.message.answer("Yoshni tanlang ❗️",reply_markup=keyboard1)
        await call.message.delete()
    if call.data == "7 yosh":
        button8 = InlineKeyboardButton(text="Scratch🕹",callback_data="scrench")
        button1 = InlineKeyboardButton(text="Kompyuter savodxonligi💻",callback_data="kompyuter")
        button18 = InlineKeyboardButton(text="Ortga qaytish⬅️",callback_data="ortga")
        keyboard3 = InlineKeyboardMarkup().add(button8).add(button1).add(button18)
        await call.message.answer("O'zingizga kerakli kursni tanlang",reply_markup=keyboard3)
        await call.message.delete()
        global s
        s+=1
        print("7 yoshdan 12 yoshgacha foydalanuvchilar soni",s)
    if call.data == "13 yosh":
        button1 = InlineKeyboardButton(text="Kompyuter savodxonligi💻",callback_data="kompyuter")
        button2 = InlineKeyboardButton(text="Dasturlash👨‍💻",callback_data="dasturlash")
        button3 = InlineKeyboardButton(text="Grafik dizyn⚙️",callback_data="dizayn")
        button4 = InlineKeyboardButton(text="Robototexnika🤖",callback_data="robototexnika")
        button5 = InlineKeyboardButton(text="Kibersport🎮",callback_data="sport")
        button18 = InlineKeyboardButton(text="Ortga qaytish⬅️",callback_data="ortga")
        keyboard10 = InlineKeyboardMarkup().add(button1).row(button2,button3).row(button4,button5).add(button18)
        await call.message.answer("Ozingizga kerakli kursni tanlang",reply_markup=keyboard10)
        await call.message.delete()
        print("13 yoshdan kattalar foydalanuvchilar soni",s+1)
    if call.data == "kompyuter":
        rasm = open("savodxonlik.jpg","rb")
        await call.message.answer_photo(photo=rasm,caption=c)
    if call.data == "dasturlash":
        button6 = InlineKeyboardButton(text="Python",callback_data="py")
        button7 = InlineKeyboardButton(text="Java",callback_data="java")
        button8 = InlineKeyboardButton(text="JavaScript",callback_data="js")
        keyboard2 = InlineKeyboardMarkup().row(button6,button7).add(button8)
        await call.message.answer("Tanlang",reply_markup=keyboard2)
    if call.data == "py":
        rasm = open("python.png","rb")
        await call.message.answer_photo(photo=rasm,caption=f"Python dasturlash kurslariga start berildi 😃\n Bu kursda siz quyidagilarni urganasiz:\n {b}❓Endilikda Python dasturlash tilini o’rganish istagi sizda paydo bo’lgan bo’lsa uni qayerdan o’rganish mumkin degan savol tug'iladi. IT Park Qorasuvda sizga sifatli ta’lim berishga tayyor hoziroq chegirma bilan kurslarimizga ro’yxatdan o’ting va o’z kelajagingiz sari qadam tashlang.\n Ro'yxatdan o'tish https://t.me/Tewayev_Abbos \n Murojaat uchun📲tel: +998557055075 \n Manzil: 80-maktab ro'parasida IT Center binosi \n Guruhga qo'shilish uchun link:https://t.me/+cr_mLE5N7EIwMDhi")
    if call.data == "dizayn":
        rasm = open("grafik.jpg","rb")
        await call.message.answer_photo(photo=rasm,caption=d)
    if call.data == "robototexnika":
        rasm = open("robot.jpg","rb")
        await call.message.answer_photo(photo=rasm,caption=r)
    if call.data == "sport":
        rasm = open("ks.jpg","rb")
        await call.message.answer_photo(photo=rasm,caption=f)
    if call.data == "java":
        rasm = open("java.png","rb")
        await call.message.answer_photo(photo=rasm,caption=java)
    if call.data == "js":
        rasm = open("JavaScript.png","rb")
        await call.message.answer_photo(photo=rasm,caption=js)
    if call.data == "scrench":
        rasm = open("scratch.jpg","rb")
        await call.message.answer_photo(photo=rasm,caption=k)
    if call.data == "savodxonlik":
        await call.message.answer("Dushanba 09:00-11:00 \n Seshanba 09:00-11:00 \n Chorshanba 09:00-11:00 \n Payshanba 09:00-11:00 \n Juma 09:00-11:00 \n Shanba 09:00-11:00 \n")
        await call.message.delete()
    if call.data == "scratch":
        await call.message.answer("Dushanba 11:00-13:00 \n Seshanba 11:00-13:00 \n Chorshanba 11:00-13:00 \n Payshanba 11:00-13:00 \n Juma 11:00-13:00 \n Shanba 11:00-13:00 \n")
        await call.message.delete()
    if call.data == "python":
        await call.message.answer("Dushanba 14:00-16:00 \n Chorshanba 14:00-16:00 \n Juma 14:00-16:00 \n 2-𝗴𝗿𝘂𝗽𝗽𝗮 𝗣𝘆𝘁𝗵𝗼𝗻:\n Dushanba 16:00-18:00 \n  Chorshanba 16:00-18:00 \n  Juma 16:00-18:00 \n")
        await call.message.delete()
    if call.data == "ja":
        await call.message.answer("Seshanba 14:00-16:00 \n Payshanba 14:00-16:00 \n Shanba 14:00-16:00 \n 2-gruppa Java: \n Seshanba 16:00-18:00 \n  Payshanba 16:00-18:00 \n  Shanba 16:00-18:00 \n ")
        await call.message.delete()
    if call.data == "grafika":
        await call.message.answer("Dushanba 14:00-16:00 \n Chorshanba 14:00-16:00 \n Juma 14:00-16:00 \n")
        await call.message.delete()
    if call.data == "fronted":
        await call.message.answer("Seshanba 14:00-16:00 \n Payshanba 14:00-16:00 \n Shanba 14:00-16:00 \n")
        await call.message.delete()
    if call.data == "tasdiqlash":
        await call.message.answer(helpp)


if __name__=="__main__":
    executor.start_polling(dp)