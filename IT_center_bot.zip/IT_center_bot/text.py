
a = '''
𝗞𝗼𝗺𝗽𝘆𝘂𝘁𝗲𝗿 𝘀𝗮𝘃𝗼𝗱𝘅𝗼𝗻𝗹𝗶𝗴𝗶💻
𝗙𝗿𝗼𝗻𝘁-𝗲𝗻𝗱✅
𝗕𝗮𝗰𝗸-𝗲𝗻𝗱👨‍💻
𝗚𝗿𝗮𝗳𝗶𝗸 𝗱𝗶𝘇𝗮𝘆𝗻𝗲𝗿⚙️
𝗠𝗼𝗯𝗶𝗹 𝗿𝗼𝗯𝗼𝘁𝗼𝘁𝗲𝘅𝗻𝗶𝗸𝗮  🤖
𝗞𝗶𝗯𝗲𝗿𝘀𝗽𝗼𝗿𝘁🎮
'''
b = '''
    Python basic
    Python OOP
    Django Framework
    Telegram Bot
'''

c = '''
Kursda nimalar o’rgatiladi?


1)Sistemani xavfsizligi va tezkorligi

2)Tez ishlash.Typing master

3)Murakkab formulalar bilan ishlash

4)Google akkaunt ochish va xavfsizlik

5)Google Yandex docs

6)Microsoft Word

7)Microsoft Exsel

8)Power Point
'''

d = '''
Grafik dizayn haqida
👨🏻‍💻 Grafik dizayner — kompyuter grafikalari yordamida muammolarga yechim taqdim etuvchi, o‘z g‘oyalarini odamlarga ko‘rsatuvchi inson.

❓Hayotimizdan grafik dizayner kasbini olib tashlasak nima bo‘ladi, bilasizlarmi? Biz Coca-Cola bilan Pepsi'ni, MacCoffee bilan Jacobs'ni, Snickers bilan Mars'ni bir ko‘rishda ajrata olmas edik. Shu sababli ushbu sohaga bo‘lgan talab nihoyatda yuqori.

Grafik dizayner — Adobe, Affinity, CorelDraw va boshqa shu kabi dasturlar yordamida logotiplar, jurnallar, bannerlar, kitob muqovalari kabi dizaynlarni tayyorlaydi.

🔹 Hammaga tanish bo‘lgan Apple, Microsoft, Google va Amazon kabi kompaniyalarning logolari ham aynan grafik dizaynerlarning mehnat mahsuli hisoblanadi.
'''

r = '''
Robototexnika-bu robotlardan tashqari avtomatlashtirilgan texnik tizimlar va ishlab chiqarish jarayonlarining eng yangi texnik integratsiyasini ishlab chiqish va ulardan foydalanish yoʻllarini oʻrganadigan fan

Avtomatlashtirilgan mashinalar, boshqacha aytganda, robotlar xavfli hududlarda yoki fabrikalarda yigʻish jarayonlarida odamlar oʻrniga ishlashi mumkin.Robotlar tashqi ko‘rinishi, xatti-harakati va idrokida odamlarga juda o‘xshash bo‘lishi mumkin.Hozirda olimlar inson shaklidagi robotlarni imkon qadar odamga o‘xshatishga harakat qilmoqda.
'''

f = '''
Elektron sport turlari - guruhli kompyuter o'yinlari bo'yicha sport musobaqalari. Musobaqalar har xil va har xil. Har bir o'yinning o'ziga xos musobaqalari va turli sovrinlari bo'ladi. Har kuni aholining 0,5% onlayn o'yinlar o'ynaydi. Dunyoga mashhur eSports o'yinlari:

1) DOTA2

2) Fortnite

3) PUBG

4) CS:GO

5) GTA 5

'''

java = '''
Java dasturlash tili va platforma
Java yuqori himoyalangan va obyektga yo’naltirilgan dashturlash tilidir.
Platforma: dastur bajarila oladigan ixtiyoriy apparat yoki dasturiy muhit platformadir. Javaning o`zini mahsus bajarilish muhiti – platformasi mavjud (JRE – Java Runtime Environment).

Javadan qayerda foydalaniladi?
Sun firmassining ma’lumotlariga qaraganda 3 mlrd. atrofidagi qurilmada javadan foydalaniladi.
Mana ulardan ba’zilari:

-Shaxsiy kompyuter dasturlari (Desktop Applications) – acrobat reader, media-player, antiviruslar va h.k.
-Web-dasturlar
-Korxona-tashkilotlar dasturlari (Enterprise Applications) – bank yoki ishlab chiqarishga oid dasturlar
-Mobil dasturlar
-Smart kartalar
-Robotlar
-O’yinlar
'''

js = '''
Ushbu dastur Liveware Javascript tilining avlodi boʻlib, Netscape serveri tomonidan ishlovchi vosita boʻladi. Ammo Javascript tilini mashhur qilgan narsa bu xaridor tomonidan dasturlashdir. Javascriptning asosiy vazifasi — HTML konteynerlar atributlarining qiymatlarini va koʻrsatuvchi muhitining xossalirini HTML sarlavhalarni koʻrish jarayonida foydalanuvchi tomonidan oʻzgartirish imkoniyatlarida, boshqacha aytganda ularni dinamik sarlavhalar qilish (DHTML) tushuniladi. Yana shuni aytish joizki, sarlavhalar qayta yuklanmaydi. Amalda buni, masalan, quydagicha ifodalash mumkin, sarlavhaning fonining rangini yoki hujjatdagi rasmni oʻzgartirish, yangi oyna ochish yoki ogohlantirish oynasini chiqarish.

„JavaScript“ nomi Netscape kompaniyasining xususiy maxsuloti hisoblanadi. Microsoft tomonidan amalga oshirilgan til rasman Jscript deb nomlanadi. Jscript versiyalari Javascriptning mos versiyalari bilan mos keladi (aniqroq qilib aytganda oxirigacha emas).
'''

k = '''
Scratch - bu asosan kodni o'rganishda yordam beradigan 8-16 yoshdagi bolalarga mo'ljallangan blokli vizual dasturlash tili va veb-sayti. Sayt foydalanuvchilari Internetda blokga o'xshash interfeys yordamida loyihalar yaratishlari mumkin. Xizmat MIT Media Lab tomonidan ishlab chiqilgan , 70 dan ortiq tillarga tarjima qilingan va dunyoning aksariyat qismlarida qo'llaniladi. Scratch maktabdan keyingi markazlarda, maktablarda va kollejlarda, shuningdek boshqa jamoat bilimlari muassasalarida o'qitiladi va qo'llaniladi.  

Scratch qiziqarli va dasturlashni  o'rganish oson bo'lishi uchun yaratilgan. Unda bloklarga asoslangan dasturlash yordamida interaktiv hikoyalar, o'yinlar , badiiy , simulyatsiya va boshqalarni yaratish uchun vositalar mavjud . Scratch-da o'zining bo'yoq muharriri va ovoz muharriri o'rnatilgan.


'''

helpp = '''
/start - Botni ishga tushirish🤖
/about -  O'quv markaz haqida⚙️
/course - O'quv markaz kurslari haqida✅
/regestratsiya - Regestratsiyadan o'tish✍️
/help - Yordam berish📌
'''